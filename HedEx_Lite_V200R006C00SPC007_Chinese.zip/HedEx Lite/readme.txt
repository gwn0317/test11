﻿**********************************************
HedEx Lite V200R006C00SPC007 2018-11-15
**********************************************

欢迎使用HedEx Lite自述文件。

（一）HedEx Lite是什么？
HedEx Lite是华为电子文档桌面管理软件，主要用于浏览、搜索、升级和管理华为电子文档。HedEx Lite是轻量版软件，只限单机使用，具有占用磁盘空间和内存小的特点。 

（二）HedEx Lite支持哪些操作系统？
（1）Microsoft Windows 2003
（2）Microsoft Windows XP Professional
（3）Microsoft Windows Vista Home Basic、Ultimate、Business、Enterprise
（4）Microsoft Windows 7
（5）Microsoft Windows 8
（6）Microsoft Windows 8.1
（7）Microsoft Windows 10

（三）HedEx Lite支持哪些浏览器？
（1）Microsoft Internet Explorer 8.0(推荐)
（2）Microsoft Internet Explorer 9.0(推荐)
（3）Microsoft Internet Explorer 10.0(推荐)
（4）Microsoft Internet Explorer 11.0
（5）Mozilla Firefox 33.0(推荐)
（6）Google Chrome 38.0(推荐)
（7）Apple Safari 5.1.7(推荐)
（8）Microsoft Edge 25.10586.0.0(推荐)

（四）如何查阅帮助信息？
启动HedEx Lite后，在HedEx Lite托盘图标中单击鼠标右键，在弹出的右键菜单中单击“HedEx Lite帮助”可查看在线帮助。如果无法启动HedEx Lite，可在HedEx Lite软件包中查看“help.chm”文件。

（五）如何启动HedEx Lite？
HedEx Lite无需安装，您只需拷贝至计算机中直接双击Startup.exe就可使用（如果是压缩包，需解压后才能使用）。







